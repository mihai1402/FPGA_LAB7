module LCD5110 (
    input  wire clk,
    output reg lcd_rst = 0,
    output reg lcd_ce  = 1,
    output reg lcd_dc  = 0,
    output reg lcd_din = 0,
    output reg lcd_clk = 0
);
    // Nokia 5110 PCD8544, FPGA 50 MHz.
    // 84 * 48 = 4032 pixels, packed in 504 bytes (6 banks x 84 columns).

    reg [7:0] bitmap [0:503];
    initial begin
        bitmap[0]=8'hFF; bitmap[1]=8'hFD; bitmap[2]=8'hD7; bitmap[3]=8'h7D; bitmap[4]=8'hEF; bitmap[5]=8'hFD; bitmap[6]=8'hDB; bitmap[7]=8'hFF; 
        bitmap[8]=8'hB5; bitmap[9]=8'hFF; bitmap[10]=8'hD5; bitmap[11]=8'h7F; bitmap[12]=8'hED; bitmap[13]=8'hFB; bitmap[14]=8'hDD; bitmap[15]=8'hF7; 
        bitmap[16]=8'hDD; bitmap[17]=8'hF3; bitmap[18]=8'hA5; bitmap[19]=8'hFF; bitmap[20]=8'hAD; bitmap[21]=8'h7A; bitmap[22]=8'hDF; bitmap[23]=8'h75; 
        bitmap[24]=8'hFF; bitmap[25]=8'h55; bitmap[26]=8'hFF; bitmap[27]=8'h55; bitmap[28]=8'hFF; bitmap[29]=8'h5D; bitmap[30]=8'hF7; bitmap[31]=8'hBD; 
        bitmap[32]=8'hEF; bitmap[33]=8'h79; bitmap[34]=8'hDF; bitmap[35]=8'hF5; bitmap[36]=8'hAF; bitmap[37]=8'hFD; bitmap[38]=8'h57; bitmap[39]=8'hFD; 
        bitmap[40]=8'hEF; bitmap[41]=8'hBA; bitmap[42]=8'h5F; bitmap[43]=8'hF5; bitmap[44]=8'h5F; bitmap[45]=8'hEA; bitmap[46]=8'hB7; bitmap[47]=8'h6D; 
        bitmap[48]=8'hDF; bitmap[49]=8'h6A; bitmap[50]=8'hB7; bitmap[51]=8'h5D; bitmap[52]=8'h36; bitmap[53]=8'h4B; bitmap[54]=8'h35; bitmap[55]=8'h2F; 
        bitmap[56]=8'h1A; bitmap[57]=8'h75; bitmap[58]=8'h2F; bitmap[59]=8'hD5; bitmap[60]=8'hBF; bitmap[61]=8'h75; bitmap[62]=8'hAF; bitmap[63]=8'hD5; 
        bitmap[64]=8'h7F; bitmap[65]=8'hD5; bitmap[66]=8'hBB; bitmap[67]=8'h6D; bitmap[68]=8'hB7; bitmap[69]=8'h6D; bitmap[70]=8'h19; bitmap[71]=8'hB7; 
        bitmap[72]=8'h0A; bitmap[73]=8'h1D; bitmap[74]=8'h03; bitmap[75]=8'h4E; bitmap[76]=8'h05; bitmap[77]=8'h2B; bitmap[78]=8'h06; bitmap[79]=8'h0D; 
        bitmap[80]=8'h5B; bitmap[81]=8'h15; bitmap[82]=8'h2F; bitmap[83]=8'h5A; bitmap[84]=8'hFF; bitmap[85]=8'hFF; bitmap[86]=8'hBB; bitmap[87]=8'hFF; 
        bitmap[88]=8'hDD; bitmap[89]=8'hFF; bitmap[90]=8'hD6; bitmap[91]=8'h7F; bitmap[92]=8'hDD; bitmap[93]=8'hF7; bitmap[94]=8'h3F; bitmap[95]=8'hED; 
        bitmap[96]=8'hB7; bitmap[97]=8'hFE; bitmap[98]=8'h2B; bitmap[99]=8'hFE; bitmap[100]=8'h17; bitmap[101]=8'h6A; bitmap[102]=8'h8F; bitmap[103]=8'h52; 
        bitmap[104]=8'h51; bitmap[105]=8'h19; bitmap[106]=8'h51; bitmap[107]=8'hA7; bitmap[108]=8'h09; bitmap[109]=8'h6F; bitmap[110]=8'h95; bitmap[111]=8'h3F; 
        bitmap[112]=8'h95; bitmap[113]=8'h7B; bitmap[114]=8'h0F; bitmap[115]=8'hB6; bitmap[116]=8'h1D; bitmap[117]=8'h57; bitmap[118]=8'h3A; bitmap[119]=8'hEF; 
        bitmap[120]=8'h5A; bitmap[121]=8'hED; bitmap[122]=8'hB7; bitmap[123]=8'hDA; bitmap[124]=8'h6F; bitmap[125]=8'hDA; bitmap[126]=8'hB7; bitmap[127]=8'h6D; 
        bitmap[128]=8'h9B; bitmap[129]=8'h56; bitmap[130]=8'h2D; bitmap[131]=8'h83; bitmap[132]=8'h15; bitmap[133]=8'h40; bitmap[134]=8'h91; bitmap[135]=8'h04; 
        bitmap[136]=8'hA0; bitmap[137]=8'h12; bitmap[138]=8'h40; bitmap[139]=8'h08; bitmap[140]=8'hA1; bitmap[141]=8'h04; bitmap[142]=8'h50; bitmap[143]=8'h02; 
        bitmap[144]=8'hA8; bitmap[145]=8'h01; bitmap[146]=8'h2B; bitmap[147]=8'h46; bitmap[148]=8'h15; bitmap[149]=8'h4B; bitmap[150]=8'h96; bitmap[151]=8'h21; 
        bitmap[152]=8'h8A; bitmap[153]=8'h21; bitmap[154]=8'h54; bitmap[155]=8'h00; bitmap[156]=8'hD4; bitmap[157]=8'h01; bitmap[158]=8'h54; bitmap[159]=8'hA0; 
        bitmap[160]=8'h15; bitmap[161]=8'h40; bitmap[162]=8'h95; bitmap[163]=8'h40; bitmap[164]=8'h15; bitmap[165]=8'hC0; bitmap[166]=8'h15; bitmap[167]=8'h40; 
        bitmap[168]=8'hFF; bitmap[169]=8'hFF; bitmap[170]=8'hFB; bitmap[171]=8'hDF; bitmap[172]=8'hFE; bitmap[173]=8'h57; bitmap[174]=8'hFD; bitmap[175]=8'hDF; 
        bitmap[176]=8'h75; bitmap[177]=8'hBF; bitmap[178]=8'h00; bitmap[179]=8'hAA; bitmap[180]=8'h04; bitmap[181]=8'hA2; bitmap[182]=8'h09; bitmap[183]=8'hE0; 
        bitmap[184]=8'hCA; bitmap[185]=8'hE1; bitmap[186]=8'hC8; bitmap[187]=8'h12; bitmap[188]=8'h85; bitmap[189]=8'h20; bitmap[190]=8'hD9; bitmap[191]=8'h82; 
        bitmap[192]=8'hB4; bitmap[193]=8'h81; bitmap[194]=8'h54; bitmap[195]=8'h02; bitmap[196]=8'h28; bitmap[197]=8'h82; bitmap[198]=8'h24; bitmap[199]=8'h0A; 
        bitmap[200]=8'h50; bitmap[201]=8'h05; bitmap[202]=8'h90; bitmap[203]=8'hEF; bitmap[204]=8'hBB; bitmap[205]=8'h56; bitmap[206]=8'hED; bitmap[207]=8'h1B; 
        bitmap[208]=8'hED; bitmap[209]=8'h12; bitmap[210]=8'hCD; bitmap[211]=8'h12; bitmap[212]=8'hE4; bitmap[213]=8'h0A; bitmap[214]=8'hF1; bitmap[215]=8'h2C; 
        bitmap[216]=8'hFA; bitmap[217]=8'h16; bitmap[218]=8'h6E; bitmap[219]=8'h16; bitmap[220]=8'hFE; bitmap[221]=8'h36; bitmap[222]=8'hDB; bitmap[223]=8'h7E; 
        bitmap[224]=8'hFC; bitmap[225]=8'hFE; bitmap[226]=8'h71; bitmap[227]=8'h04; bitmap[228]=8'h58; bitmap[229]=8'h83; bitmap[230]=8'h34; bitmap[231]=8'h41; 
        bitmap[232]=8'h94; bitmap[233]=8'h29; bitmap[234]=8'h44; bitmap[235]=8'h92; bitmap[236]=8'h28; bitmap[237]=8'h45; bitmap[238]=8'h92; bitmap[239]=8'h29; 
        bitmap[240]=8'h44; bitmap[241]=8'h92; bitmap[242]=8'h29; bitmap[243]=8'h44; bitmap[244]=8'h92; bitmap[245]=8'h29; bitmap[246]=8'h44; bitmap[247]=8'h92; 
        bitmap[248]=8'h49; bitmap[249]=8'hB4; bitmap[250]=8'h02; bitmap[251]=8'h69; bitmap[252]=8'hFF; bitmap[253]=8'h7F; bitmap[254]=8'hF6; bitmap[255]=8'hDF; 
        bitmap[256]=8'h77; bitmap[257]=8'hBD; bitmap[258]=8'hD7; bitmap[259]=8'hFD; bitmap[260]=8'hA7; bitmap[261]=8'hFD; bitmap[262]=8'h02; bitmap[263]=8'h80; 
        bitmap[264]=8'h2A; bitmap[265]=8'h40; bitmap[266]=8'h09; bitmap[267]=8'h9F; bitmap[268]=8'h1D; bitmap[269]=8'h9F; bitmap[270]=8'h19; bitmap[271]=8'hF4; 
        bitmap[272]=8'hFA; bitmap[273]=8'h7F; bitmap[274]=8'h5A; bitmap[275]=8'hF7; bitmap[276]=8'hAC; bitmap[277]=8'h5F; bitmap[278]=8'hFB; bitmap[279]=8'h5F; 
        bitmap[280]=8'hBE; bitmap[281]=8'h1C; bitmap[282]=8'hE0; bitmap[283]=8'h09; bitmap[284]=8'hA2; bitmap[285]=8'h04; bitmap[286]=8'h7A; bitmap[287]=8'hC5; 
        bitmap[288]=8'h3A; bitmap[289]=8'hD5; bitmap[290]=8'hAA; bitmap[291]=8'h55; bitmap[292]=8'hEA; bitmap[293]=8'h15; bitmap[294]=8'hEA; bitmap[295]=8'h15; 
        bitmap[296]=8'hEA; bitmap[297]=8'h14; bitmap[298]=8'hEB; bitmap[299]=8'h52; bitmap[300]=8'hA6; bitmap[301]=8'hD7; bitmap[302]=8'h24; bitmap[303]=8'hF3; 
        bitmap[304]=8'h4E; bitmap[305]=8'hB2; bitmap[306]=8'h47; bitmap[307]=8'hEA; bitmap[308]=8'h35; bitmap[309]=8'hEB; bitmap[310]=8'hF6; bitmap[311]=8'h59; 
        bitmap[312]=8'hBC; bitmap[313]=8'h73; bitmap[314]=8'h34; bitmap[315]=8'hC9; bitmap[316]=8'h24; bitmap[317]=8'h5B; bitmap[318]=8'h80; bitmap[319]=8'h56; 
        bitmap[320]=8'hA9; bitmap[321]=8'h12; bitmap[322]=8'hA4; bitmap[323]=8'h49; bitmap[324]=8'h12; bitmap[325]=8'hA4; bitmap[326]=8'h49; bitmap[327]=8'h12; 
        bitmap[328]=8'hA4; bitmap[329]=8'h49; bitmap[330]=8'h12; bitmap[331]=8'h64; bitmap[332]=8'h89; bitmap[333]=8'h36; bitmap[334]=8'hC9; bitmap[335]=8'h12; 
        bitmap[336]=8'h6F; bitmap[337]=8'hFF; bitmap[338]=8'h37; bitmap[339]=8'hFD; bitmap[340]=8'h2F; bitmap[341]=8'hFB; bitmap[342]=8'h2E; bitmap[343]=8'hDB; 
        bitmap[344]=8'h2E; bitmap[345]=8'hFB; bitmap[346]=8'h40; bitmap[347]=8'hA8; bitmap[348]=8'h62; bitmap[349]=8'hA0; bitmap[350]=8'hBA; bitmap[351]=8'h60; 
        bitmap[352]=8'h9A; bitmap[353]=8'hF4; bitmap[354]=8'hDE; bitmap[355]=8'hB1; bitmap[356]=8'hFF; bitmap[357]=8'hC4; bitmap[358]=8'h53; bitmap[359]=8'h8A; 
        bitmap[360]=8'h5C; bitmap[361]=8'hA2; bitmap[362]=8'h56; bitmap[363]=8'h8C; bitmap[364]=8'h6A; bitmap[365]=8'hCF; bitmap[366]=8'h31; bitmap[367]=8'h04; 
        bitmap[368]=8'hA0; bitmap[369]=8'h08; bitmap[370]=8'hF7; bitmap[371]=8'h6E; bitmap[372]=8'h9B; bitmap[373]=8'hF6; bitmap[374]=8'hD5; bitmap[375]=8'hAE; 
        bitmap[376]=8'hD5; bitmap[377]=8'h3A; bitmap[378]=8'hD5; bitmap[379]=8'h95; bitmap[380]=8'h6D; bitmap[381]=8'h81; bitmap[382]=8'hFD; bitmap[383]=8'h01; 
        bitmap[384]=8'hEA; bitmap[385]=8'h95; bitmap[386]=8'hE4; bitmap[387]=8'h99; bitmap[388]=8'h65; bitmap[389]=8'h9A; bitmap[390]=8'hE5; bitmap[391]=8'h9D; 
        bitmap[392]=8'h61; bitmap[393]=8'h99; bitmap[394]=8'h76; bitmap[395]=8'hBB; bitmap[396]=8'hED; bitmap[397]=8'hF7; bitmap[398]=8'hDF; bitmap[399]=8'hB4; 
        bitmap[400]=8'h6B; bitmap[401]=8'hBE; bitmap[402]=8'hED; bitmap[403]=8'h9A; bitmap[404]=8'h6E; bitmap[405]=8'h9A; bitmap[406]=8'h74; bitmap[407]=8'hAF; 
        bitmap[408]=8'hF8; bitmap[409]=8'hAE; bitmap[410]=8'hD9; bitmap[411]=8'h6C; bitmap[412]=8'hF4; bitmap[413]=8'h5D; bitmap[414]=8'hBA; bitmap[415]=8'hD5; 
        bitmap[416]=8'h7C; bitmap[417]=8'hA9; bitmap[418]=8'hFE; bitmap[419]=8'hA9; bitmap[420]=8'hDB; bitmap[421]=8'hB6; bitmap[422]=8'h69; bitmap[423]=8'hDF; 
        bitmap[424]=8'hF4; bitmap[425]=8'h5B; bitmap[426]=8'hFD; bitmap[427]=8'hF6; bitmap[428]=8'hBB; bitmap[429]=8'hED; bitmap[430]=8'hFE; bitmap[431]=8'hED; 
        bitmap[432]=8'hBB; bitmap[433]=8'hF6; bitmap[434]=8'hED; bitmap[435]=8'hBB; bitmap[436]=8'hD6; bitmap[437]=8'h7B; bitmap[438]=8'hEF; bitmap[439]=8'h5E; 
        bitmap[440]=8'hFB; bitmap[441]=8'hBF; bitmap[442]=8'hFA; bitmap[443]=8'hFD; bitmap[444]=8'hFE; bitmap[445]=8'hF9; bitmap[446]=8'h9E; bitmap[447]=8'hFD; 
        bitmap[448]=8'hFE; bitmap[449]=8'hFF; bitmap[450]=8'hE0; bitmap[451]=8'hAA; bitmap[452]=8'h50; bitmap[453]=8'h8C; bitmap[454]=8'hAB; bitmap[455]=8'h7D; 
        bitmap[456]=8'hEF; bitmap[457]=8'h3D; bitmap[458]=8'hF7; bitmap[459]=8'h5E; bitmap[460]=8'hFB; bitmap[461]=8'hFD; bitmap[462]=8'hBF; bitmap[463]=8'hEA; 
        bitmap[464]=8'h7F; bitmap[465]=8'hD7; bitmap[466]=8'hFD; bitmap[467]=8'hAB; bitmap[468]=8'hFF; bitmap[469]=8'hD6; bitmap[470]=8'hBD; bitmap[471]=8'hDF; 
        bitmap[472]=8'hF5; bitmap[473]=8'hBB; bitmap[474]=8'hDE; bitmap[475]=8'hF5; bitmap[476]=8'h3F; bitmap[477]=8'hA2; bitmap[478]=8'h9F; bitmap[479]=8'hBD; 
        bitmap[480]=8'h2F; bitmap[481]=8'h7A; bitmap[482]=8'h5F; bitmap[483]=8'hF7; bitmap[484]=8'hFD; bitmap[485]=8'hDB; bitmap[486]=8'hFD; bitmap[487]=8'hE6; 
        bitmap[488]=8'h9B; bitmap[489]=8'hE4; bitmap[490]=8'h5B; bitmap[491]=8'hB4; bitmap[492]=8'hCB; bitmap[493]=8'h36; bitmap[494]=8'hCD; bitmap[495]=8'h3F; 
        bitmap[496]=8'hEE; bitmap[497]=8'hDB; bitmap[498]=8'hAD; bitmap[499]=8'hFB; bitmap[500]=8'hAF; bitmap[501]=8'hD6; bitmap[502]=8'h7D; bitmap[503]=8'hEE; 
    end

    function [7:0] init_byte;
        input [2:0] n;
        begin
            case (n)
                0: init_byte = 8'h21;  // Extended instruction set
                1: init_byte = 8'hB8;  // Vop / contrast (adjust as needed)
                2: init_byte = 8'h04;  // Temperature coefficient
                3: init_byte = 8'h14;  // Bias
                4: init_byte = 8'h20;  // Basic instruction set
                5: init_byte = 8'h0C;  // Normal display mode
                6: init_byte = 8'h80;  // X = 0
                7: init_byte = 8'h40;  // Y bank = 0
                default: init_byte = 8'h00;
            endcase
        end
    endfunction

    reg phase = 0;              // 0: init, 1: bitmap
    reg [9:0] pos = 0;         // 0..503
    wire [7:0] tx_byte = phase ? bitmap[pos] : init_byte(pos[2:0]);

    localparam RESET_LOW  = 4'd0;
    localparam RESET_HIGH = 4'd1;
    localparam LOAD       = 4'd2;
    localparam CLOCK_UP   = 4'd3;
    localparam CLOCK_DOWN = 4'd4;
    localparam BYTE_END   = 4'd5;
    localparam ADVANCE    = 4'd6;
    localparam DONE       = 4'd7;

    reg [3:0] state = RESET_LOW;
    reg [21:0] timer = 0;
    reg [5:0] spi_div = 0;
    reg [7:0] shift_byte = 0;
    reg [2:0] bit_index = 0;

    always @(posedge clk) begin
        case (state)
            RESET_LOW: begin
                lcd_rst <= 0;
                lcd_ce <= 1;
                lcd_clk <= 0;
                if (timer == 22'd999999) begin
                    timer <= 0;
                    lcd_rst <= 1;
                    state <= RESET_HIGH;
                end else timer <= timer + 1'b1;
            end
            RESET_HIGH: begin
                if (timer == 22'd2499999) begin
                    timer <= 0;
                    state <= LOAD;
                end else timer <= timer + 1'b1;
            end
            LOAD: begin
                lcd_ce <= 0;
                lcd_dc <= phase;
                lcd_clk <= 0;
                lcd_din <= tx_byte[7];
                shift_byte <= tx_byte;
                bit_index <= 7;
                spi_div <= 0;
                state <= CLOCK_UP;
            end
            CLOCK_UP: begin
                if (spi_div == 49) begin
                    spi_div <= 0;
                    lcd_clk <= 1;
                    state <= CLOCK_DOWN;
                end else spi_div <= spi_div + 1'b1;
            end
            CLOCK_DOWN: begin
                if (spi_div == 49) begin
                    spi_div <= 0;
                    lcd_clk <= 0;
                    if (bit_index == 0) state <= BYTE_END;
                    else begin
                        bit_index <= bit_index - 1'b1;
                        lcd_din <= shift_byte[6];
                        shift_byte <= {shift_byte[6:0],1'b0};
                        state <= CLOCK_UP;
                    end
                end else spi_div <= spi_div + 1'b1;
            end
            BYTE_END: begin
                lcd_ce <= 1;
                state <= ADVANCE;
            end
            ADVANCE: begin
                if (phase && pos == 10'd503)
                    state <= DONE;
                else begin
                    if (!phase && pos == 10'd7) begin
                        phase <= 1;
                        pos <= 0;
                    end else pos <= pos + 1'b1;
                    state <= LOAD;
                end
            end
            DONE: begin
                lcd_ce <= 1;
                lcd_clk <= 0;
            end
            default: state <= RESET_LOW;
        endcase
    end
endmodule